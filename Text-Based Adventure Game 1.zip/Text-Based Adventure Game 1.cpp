#include <iostream>
#include <string>
#include <map>
#include <vector>


class Item{
	public:
		std::string name;
		std::string description;
		
		Item(const std::string& _name, const std::string& _descrption)
		: name(_name), description(description){}
		};
class Location{
	public:
		std::string name;
		std::string description;
		std::map<std::string, Item> items;
		
		Location(const std::string& _name, const std::string& _description)
		: name(_name), description(_description){}
		
		
		void addItem(const Item& item){
			items[item.name] = item;
		}
};

class Player{
	public:
	Location* currentLocation;
	std::vector<Item> inventory;
	
	Player() : currentLocation(NULL){}
	void moveTo(Location& location){
		currentLocation = &location;
		std::cout << "You are now at"<< location.name<<"."<<location.description<<"\n";
	}
	void listInventory(){
		std::cout<<"Inventory:\n";
		for(size_t i=0; i<inventory.size(); ++i){
			std::cout <<"- "<< inventory[i].name<<": "<<inventory[i].description<<"\n";
		}
	}
	
};

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	//Create locations and items
	Location start("Starting Room","You find yourself in a dimly lit room.");
	Item key("Key","A small rusty key.");
	start.addItem(key);
	
	Location garden("Garden","You are in a beautiful garden with colorful flowers.");
	Item flower("Flower","A pretty flower.");
	garden.addItem(flower);
	
	//Set up player and starting location
	Player player;
	player.moveTo(start);
	
	// Game loop
	while(true){
		std::string command;
		std::cout << "\nEnter a command: ";
		std::cin >> command;
		
		if(command=="move"){
			std::string destination;
			std::cout << "Where would you like to go?";
			std::cin>> destination;
			
			if(destination=="garden"){
				player.moveTo(garden);
			}
			else{
				std::cout<< "You can't go there.\n";
			}
		}
		else if(command == "Inventory"){
			player.listInventory();
		}
		else if(command == "quit"){
			std::cout<<"Thanks for playing!\n";
			break;
		}
		else{
			std::cout << "Invalid command. Try 'move','inventory', or 'quit'.\n";
		}
	}
	return 0;
}
