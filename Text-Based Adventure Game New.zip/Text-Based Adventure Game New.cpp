#include <iostream>
#include <string>
#include <vector>
#include <map>

class GameObject {
public:
    virtual std::string getDescription() const = 0;
    virtual void interact() {}
};

class Location : public GameObject {
private:
    std::string name;
    std::string description;
    std::vector<GameObject*> objects;

public:
    Location(const std::string& _name, const std::string& _description)
        : name(_name), description(_description) {}

    void addObject(GameObject* object) {
        objects.push_back(object);
    }

    std::string getDescription() const {
        return description;
    }

    void interact() {
        std::cout << "You are at " << name << ". " << getDescription() << std::endl;
        std::cout << "You see the following objects:" << std::endl;

        for (size_t i = 0; i < objects.size(); ++i) {
            std::cout << "- " << objects[i]->getDescription() << std::endl;
        }
    }
};

class Item : public GameObject {
private:
    std::string name;
    std::string description;

public:
    Item(const std::string& _name, const std::string& _description)
        : name(_name), description(_description) {}

    std::string getDescription() const {
        return name + ": " + description;
    }

    void interact() {
        std::cout << "You examine the " << name << ". " << description << std::endl;
    }
};

class Player {
private:
    Location* currentLocation;
    std::map<std::string, Item*> inventory;

public:
    Player(Location* startingLocation)
        : currentLocation(startingLocation) {}

    void move(Location* newLocation) {
        currentLocation = newLocation;
    }

    void take(Item* item) {
        inventory[item->getDescription()] = item;
    }

    void showInventory() const {
        std::cout << "Inventory:" << std::endl;

        for (std::map<std::string, Item*>::const_iterator it = inventory.begin(); it != inventory.end(); ++it) {
            std::cout << "- " << it->first << std::endl;
        }
    }

    void interactWithLocation() {
        currentLocation->interact();
    }
};

int main() {
    // Create game objects
    Location startingLocation("Forest", "A dense forest with towering trees.");
    Item sword("Sword", "A sharp sword forged from steel.");
    Item potion("Health Potion", "A potion that restores health.");

    // Set up relationships
    startingLocation.addObject(&sword);
    startingLocation.addObject(&potion);

    Player player(&startingLocation);

    std::cout << "Welcome to the Text-Based Adventure Game!" << std::endl;

    bool isRunning = true;
    while (isRunning) {
        std::cout << "\nWhat do you want to do?" << std::endl;
        std::cout << "1. Look around" << std::endl;
        std::cout << "2. Check inventory" << std::endl;
        std::cout << "3. Quit" << std::endl;

        int choice; // Declare the 'choice' variable here
        std::cin >> choice;

        switch (choice) {
            case 1:
                player.interactWithLocation();
                break;
            case 2:
                player.showInventory();
                break;
            case 3:
                isRunning = false;
                std::cout << "Thanks for playing!" << std::endl;
                break;
            default:
                std::cout << "Invalid choice. Please select a valid option." << std::endl;
        }
    }

    return 0;
}

